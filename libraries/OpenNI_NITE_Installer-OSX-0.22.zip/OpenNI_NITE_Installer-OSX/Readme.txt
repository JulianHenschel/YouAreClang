SimpleOpenNI - OpenNI/NITE Installer for OSX
--------------------------------------------

How to install:

1. Unzip the file 'OpenNI_NITE_Installer-OSX.zip'
2. Go into the folder 'OpenNI_NITE_Installer-OSX', for example:
	> cd ./OpenNI_NITE_Installer-OSX
3. Start the installer
	> sudo ./install.sh
	
The libraries are part of OpenNI/NITE(http://www.openni.org/)

	



